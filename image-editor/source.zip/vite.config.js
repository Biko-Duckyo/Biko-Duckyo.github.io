import { defineConfig } from 'vite'
export default defineConfig({ base: '/image-editor/', build: { outDir: '../../source/image-editor', emptyOutDir: false }, server: { fs: { allow: ['../..'] } } })
