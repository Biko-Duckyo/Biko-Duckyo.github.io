# 鸭喵屋随手修图（GPL-3.0-only）

Independent static page; home card links to /image-editor/. Built output lives in source/image-editor/.

FaceStudio engines vendored from https://github.com/georgegach/facestudio (master snapshot downloaded 2026-11-12). Upstream copyright George Gach 2018–2026; full GPL license in public/licenses. No analytics. Filerobot 4.9.0 MIT UMD self-hosted; no backend translation service. Combined integration source distributed under GPL-3.0-only.

Build (Node 20+): npm ci; download the following model assets, run node prepare.mjs then npm run build. Large model is split into checked chunks for Pages. See prepare.mjs for SHA256. Runtime reassembles and validates it. Copy the resulting source/image-editor into the Hexo public output (Hexo skips rendering its raw HTML).

- public/models/face_landmarker.task: https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task
- ../../.tmp/face_parsing.onnx: https://github.com/yakhyo/face-parsing/releases/download/weights/resnet18.onnx (MIT).
- public/filerobot-4.9.0.min.js: https://scaleflex.cloudimg.io/v7/plugins/filerobot-image-editor/4.9.0/filerobot-image-editor.min.js
- public/sample.jpg: upstream public/presets/presidents/barak-obama.jpg

Changes to FaceStudio: new UI; exposed smooth, face slim, bokeh background, teeth whitening, smile, eye size, nose slim and brow define; wired the lightweight general ONNX 4x upscaler as an isolated local pixel-resolution action; unused makeup/color/replace/age paths remain disabled; no analytics; forced portable WASM execution provider; same-origin model assets; checksummed chunk assembly; retry landmarker load on failure; dispose tensors and bound parsing cache. Runtime image long edge capped to 1280 on narrow screens / 1600 on desktop; upscale input is further capped to 448 mobile / 512 desktop to bound RAM. Largest face is edited. All slider edits rerender from the current base (no accumulated warps). Basic editor save commits a new base; original comparison remains the imported original.

Package corresponding source as public/source.zip excluding node_modules, build outputs and model binaries. Dependency versions locked; models and runtime URLs above reproduce binary assets.
