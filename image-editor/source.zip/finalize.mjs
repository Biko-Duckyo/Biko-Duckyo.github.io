import { readFileSync, writeFileSync } from 'node:fs'
// Hexo raw standalone documents, like the existing scholar/books apps.
for (const name of ['index.html', 'about.html']) {
  const file = new URL(`../../source/image-editor/${name}`, import.meta.url)
  writeFileSync(file, '---\nlayout: false\n---\n' + readFileSync(file, 'utf8'))
}
