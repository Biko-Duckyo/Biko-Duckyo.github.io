# 修图工具竞品对照与分层改造清单

更新时间：2026-11-12。口径：只记录公开页面已能确认的功能；本站是静态 Hexo 页面，照片优先浏览器本地处理，不接入需上传账号、密钥或订阅的云端 AI，除非后续单独拍板。

## 1. 当前本地能力基线

### 1.1 已接入并可在 UI 使用

- FaceStudio 本地人脸与形变：磨皮、瘦脸、背景虚化、牙齿美白、微笑、眼睛大小、鼻型收窄、眉形清晰。
- 本地 general ONNX 轻量 4x 像素放大：输入长边上限手机 448px / 桌面 512px；不做生成式纹理重建。
- Filerobot 本地基础编辑：裁剪、旋转、翻转、亮度/对比度/饱和度/曝光/色温/HSV、滤镜、标注、模糊遮挡、尺寸/质量/格式。
- 单图导入、示例图、原图对比、下载 PNG；多人照片默认处理最大人脸。
- 照片不上传；模型/WASM 按需从本站或运行时缓存加载。桌面长边上限 1600px，手机长边上限 1280px。

### 1.2 引擎内已有但尚未接入 UI 的本地参数

- 妆容/颜色：唇色、腮红、眉形、眼色、发色、发型体积。
- 场景：暗角、studio 背景。
- 年龄：ageEnabled、sourceAge、targetAge。
- 超分：`upscale.ts` 的 general 1.8MB 模型已接 UI；photo 33.7MB 与 anime 68.3MB 档位仍未暴露。

### 1.3 明确边界

- 不提供通用 AI 物体消除/inpainting；杂物目前只能裁剪、标注或模糊遮挡。
- 不提供 AI 换脸、换装、肤色重绘、身形重塑、AI 文生图、海报生成、AI 背景生成、批量处理、黑白上色、视频增强。
- 本地 ONNX/WASM 模型受包体、手机内存、首次下载体积、许可、跨域隔离和离线缓存影响。

## 2. 公开产品功能对照

| 产品 | 公开确认的主要功能 | 可借鉴点 | 本站当前差距 | 可行性判断 |
|---|---|---|---|---|
| ImgGood | 去背、物体擦除、图片增强、超分放大、扩图、黑白上色、换脸、发型调整、文生图、海报、线稿、风格迁移、批量去背/改尺寸/裁剪/格式转换；免费额度受限，HD/批量/部分 AI 走 credits 或 Pro | 把修图拆成“人像美化、背景处理、缺陷清除、清晰放大、风格创作、批量”几组能力 | 只有人像美化与基础编辑；去背、消除、超分、扩图、上色、换脸、风格化、批量均未落地 | 基础裁剪/调色可保留；本地抠图/消除/超分需另接模型；生成/换脸/上色/批量列入云端或高风险候选 |
| Remove.bg | AI 背景移除、高分辨率抠像、Magic Brush 擦除/恢复、AI Magic Background、纯色/图片背景、背景模糊/阴影、颜色光线、裁剪摆放、扩图、文字/元素/模板；部分 AI 跳转 Canva | 主体抠像、边缘擦除/恢复、背景替换、背景模糊/阴影、扩图 | 当前只有人像背景虚化；没有透明抠图、主体边缘修整、纯色/图片背景替换、AI 背景或扩图 | 本地抠图候选需核查 AGPL、模型体积、COOP/COEP、WebGPU/WASM；背景阴影/摆放属于二次设计，暂不做 |
| Magnific AI | 2x/4x/8x/16x、prompt 引导、题材预设、Creativity/HDR/Resemblance/Fractality/Sharpness/Smart grain、Illusio/Sharpy/Sparkle 引擎；生成式重建纹理与细节，云端付费 | 分档放大、题材预设、锐化/颗粒控制、不同超分模型选择 | 已有本地 general 固定 4x；没有 prompt、8x/16x、生成式细节或题材预设，photo/anime 大模型未暴露 | 本地 general 4x 已跑通；prompt 引导、生成式重建、8x/16x 属于云端大模型路线，不适合当前静态站 |
| Remini | 去模糊/锐化、2x 放大、老照片修复、降噪、人像增强、色彩修正、Face Glow/Auto Color/Background Enhance、视频增强；免费含广告，高级走会员 | 人像细节增强、去模糊、降噪、色彩修正、老照片修复、有限放大 | Filerobot 只有基础调色；已有本地 general 4x，但没有 AI 去模糊、去噪、修复或老照片还原 | 本地轻量锐化/对比与 general 4x 可保留；AI 去模糊/降噪/老照片修复需模型与实测；视频增强排除 |
| WonderPic | 文生图/图生图、40+ 风格（Cartoon/Anime/Ghibli/水彩/铅笔/炭笔/墨画/像素等）、肤色调整、Body Reshape/Face Slim/Full Body、正装替换、高清导出；免费每日次数，Starter $9.99/月、Pro $19.99/月、Ultra $39.99/月 | 风格化分组、肤色/身形/脸型微调、正装证件感、高清导出 | 只有瘦脸；没有肤色、身形、服装替换、风格化或文生/图生图 | 肤色/身形/换装需要专门模型或云端生成；风格化与文生图列入高风险云端候选；本地只保留几何形变 |
| TraceCut | 多轮中英文检索未定位到同名 AI 修图/抠图产品；结果来自工业切削液、超声设备菜单或近似抠图工具 | 暂无可靠功能可归属 | 不假设其能力 | 未确认前不写入功能规划；如用户有官网/截图，再补来源 |

## 3. 本地替代方案与风险核查

### 3.1 `@imgly/background-removal`

- 形态：浏览器内 ONNX Runtime 背景移除，支持 CPU/WebGPU；输出前景/背景/蒙版；模型/WASM 可远程加载或通过 `publicPath` 自托管。
- 体积：small 约 40MB，medium 约 80MB。
- 风险：许可为 AGPL，商业/闭源集成需另谈授权；可能需要 SharedArrayBuffer 对应的 COOP/COEP 跨域隔离；手机内存和首次下载体积需实测。
- 结论：P2 候选。先解决许可、响应头、模型自托管与低内存设备回退，再接 UI。

### 3.2 inpaint-web 本地消除与超分

- 仓库：`https://github.com/lxfater/inpaint-web`，GPL-3.0；React 17、opencv-ts、localforage；模型运行时从 HuggingFace 下载后 IndexedDB 缓存。
- 消除模型：MI-GAN pipeline v2，实测约 26.8MB。
- 超分模型：Real-ESRGAN x4，实测约 63.9MB。
- 风险：需要画笔/框选/套索蒙版 UX；消除结果依赖局部纹理；手机 CPU/WASM 耗时和内存需实测；现有脚手架是原生 JS，接入需要兼容层。
- 结论：消除与 Real-ESRGAN 超分列 P3/P4，不与现有磨皮按钮混在一起。

### 3.3 现有 FaceStudio `upscale.ts`

- 固定 4x；tile 192、overlap 16；当前 ort.ts 强制便携 WASM 单线程路径，兼容 iOS Safari 与非跨域隔离页面。
- 模型来自 HuggingFace：
  - `4x-UltraSharpV2_Lite.onnx`：实测约 33.7MB。
  - `4x-AnimeSharp.onnx`：实测约 68.3MB。
  - `4x-ClearRealityV1.onnx`：实测约 1.8MB，已接入 UI。
- 实测（2026-11-12，headless Chrome）：输入长边桌面 512px / 手机 448px；桌面输出 1576×2048，手机输出 1380×1792；无 JS 异常；仅已知 busuanzi 外链失败。
- 剩余风险：远程模型首次下载与缓存、手机 WASM 耗时、大图内存、1.8MB 模型纹理重建能力有限；photo/anime 大模型未暴露。
- 结论：general 轻量档位作为 P1 已落地；photo/anime 两个大模型作为后续可选档位，不上首屏。

### 3.4 UpscalerJS

- 开源 MIT 包装，TensorFlow.js 运行时；ESRGAN Slim 原始模型 Apache 2.0；pretrained 模型按需安装。
- 风险：会在现有 ONNX Runtime Web 之外引入 TF.js 运行时和另一套模型体系。
- 结论：除非现有 ONNX 超分实测失败，否则不优先接入。

## 4. 分阶段改造建议

### P0：无新模型，补齐现有本地人像参数（本轮已落地）

- 已接入：牙齿美白、微笑、眼睛大小、鼻型收窄、眉形清晰。
- 保留：磨皮、瘦脸、背景虚化、Filerobot 基础编辑、原图对比、本地下载。
- 验证：桌面 1440×900 与 iPhone 15 口径 393×852@2x；示例图应用后画布非白；桌面 1231×1600，手机 985×1280；无横向溢出。

### P1：本地轻量超分试验（已落地首档）

- 已接入现有 `upscale.ts` 的 general 1.8MB ONNX；UI 为独立“本地放大 4x”按钮。
- 输入长边上限手机 448px / 桌面 512px，避免 4x 后内存爆增；下载/推理进度在状态条显示，失败保留当前画面。
- 双视口实测：桌面输出 1576×2048，手机输出 1380×1792；无横向溢出、无 JS 异常。
- 明确口径：这是像素级非生成式超分，不是 Remini/Magnific 式 AI 去模糊、老照片修复或纹理重建。
- 若 general 效果不足，再评估 33.7MB photo 模型；68.3MB anime 模型只做可选。

### P2：本地抠图（需先过许可与兼容门）

- 门：AGPL 授权结论、COOP/COEP 是否可配置、small/medium 模型体积与手机内存、透明 PNG 输出、边缘擦除/恢复 UX。
- 不达标就保留“背景虚化 + 裁剪”，不承诺去背。
- 达标后可做：透明抠像、纯色背景替换；图片背景合成与 AI 背景生成后置。

### P3：本地涂抹消除（模型+画布交互另立）

- 门：MI-GAN 模型体积、蒙版画笔、撤销/重做、局部预览、手机性能、GPL 许可兼容。
- 先做小面积路人/水印/杂物；明确不保证大区域自然修补。

### P4：本地降噪/去模糊/老照片修复（候选）

- 先找 Apache/MIT/宽松许可且可浏览器运行的 ONNX/WASM 模型；用样例图对比清晰度、涂抹感和边缘。
- 不把普通锐化包装成 AI 去模糊；不接入云端修复 API。

### 明确暂不做

- 文生图、图生图风格化、AI 海报、AI 背景生成、换脸、换装、肤色重绘、身形重塑、8x/16x 生成式放大、批量处理、黑白上色、视频增强。
- 这些能力通常需要上传图片、账号、密钥、订阅、大模型推理或专门商业许可；与当前静态站、本地隐私和无支付链路约束冲突。

## 5. 来源

- ImgGood 目录摘要：`https://somi.ai/products/img-good`
- Remove.bg 功能与博客：
  - `https://www.remove.bg/ja/a/background-remover-windows-mac-linux`
  - `https://www.remove.bg/vi/b/introducing-higher-resolutions-support`
  - `https://www.remove.bg/th/help/a/how-to-enhance-your-background-with-the-new-magic-background-feature`
  - `https://www.remove.bg/ru/b/fresh-design-advanced-features`
  - `https://www.remove.bg/pl/b/introducing-remove-bg-ai-background-generator`
- Magnific AI：`https://magnific.ai/editor/`、`https://magnific.ai/tutorials/quick-start-guides/magnific-upscaler.md`
- Remini：`https://remini.ai/`
- WonderPic：`https://wonderpic.art/`、`https://wonderpic-ai-photo-editor.software.informer.com/`
- PicWish 近似能力参考：`https://picwish.com/tw/faq/how-to-use-picwish-windows.html`
- 本地候选：
  - `https://www.npmjs.com/package/@imgly/background-removal`
  - `https://github.com/lxfater/inpaint-web`
  - `https://upscalerjs.com/`
