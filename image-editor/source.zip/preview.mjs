import http from 'node:http'
import fs from 'node:fs'
import path from 'node:path'
const root = path.resolve('../..')
const types = {'.html':'text/html; charset=utf-8','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.wasm':'application/wasm','.json':'application/json','.jpg':'image/jpeg','.png':'image/png','.svg':'image/svg+xml','.woff2':'font/woff2','.ico':'image/x-icon','.xml':'application/xml'}
http.createServer((req,res) => {
  const pathname = decodeURIComponent(new URL(req.url,'http://localhost').pathname)
  let relative = pathname.replace(/^\/+/, ''); if (!path.extname(relative)) relative += relative.endsWith('/') ? 'index.html' : '/index.html'
  const directory = relative.startsWith('image-editor/') || relative === 'js/home_dashboard.js' ? 'source' : 'public'
  const target = path.resolve(root, directory, relative)
  if (!target.startsWith(path.join(root,directory)+path.sep)) { res.writeHead(403).end(); return }
  if (!fs.existsSync(target) || !fs.statSync(target).isFile()) { res.writeHead(404).end('Not found');return }
  res.setHeader('Content-Type',types[path.extname(target)] || 'application/octet-stream')
  res.setHeader('Content-Length',fs.statSync(target).size)
  res.setHeader('Cache-Control','no-cache');fs.createReadStream(target).pipe(res)
}).listen(4020,'127.0.0.1',() => console.log('Photo preview http://127.0.0.1:4020/image-editor/'))
