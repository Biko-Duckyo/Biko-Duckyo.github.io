import './style.css'

const $ = (id) => document.getElementById(id)
const canvas = $('result'), ctx = canvas.getContext('2d')
const dialog = $('basic-dialog')
let base = null, result = null, original = null, face = null, engine = null, busy = false, comparing = false
let fileName = 'photo', editor = null, scriptPromise = null, dirtyBasic = false
let changed = false
const controls = ['smooth', 'slim', 'blur', 'teeth', 'smile', 'eyes', 'nose', 'brow']

function status(message, error = false) { $('status').textContent = message; $('status').classList.toggle('error', error) }
function lock(value) {
  busy = value
  $('beauty').disabled = value || !base
  for (const id of ['basic', 'download', 'compare', 'upscale']) $(id).disabled = value || !base
  for (const id of ['choose', 'sample', 'empty-choose']) $(id).disabled = value
  $('apply').textContent = value ? '正在处理…' : '应用效果'
  $('upscale').textContent = value ? '正在放大…' : '本地放大 4x'
}
function draw(image) {
  canvas.width = image.width; canvas.height = image.height
  ctx.putImageData(image, 0, 0)
}
function endCompare() { comparing = false; $('compare').setAttribute('aria-pressed', 'false'); $('compare').textContent = '查看原图'; if (result) draw(result) }
function resetSliders() { for (const id of controls) { $(id).value = 0; $(`${id}-value`).value = '0' } }
async function decode(blob) {
  let image
  try { image = await createImageBitmap(blob, { imageOrientation: 'from-image' }) }
  catch { throw new Error('暂时无法读取这张图片，请换成 JPG、PNG 或 WebP。') }
  const limit = matchMedia('(max-width: 760px)').matches ? 1280 : 1600
  const ratio = Math.min(1, limit / Math.max(image.width, image.height))
  const temp = document.createElement('canvas')
  temp.width = Math.max(1, Math.round(image.width * ratio)); temp.height = Math.max(1, Math.round(image.height * ratio))
  const context = temp.getContext('2d'); context.drawImage(image, 0, 0, temp.width, temp.height); image.close()
  return context.getImageData(0, 0, temp.width, temp.height)
}
function resizeForUpscale(img, maxEdge) {
  const ratio = Math.min(1, maxEdge / Math.max(img.width, img.height))
  if (ratio === 1) return img
  const source = document.createElement('canvas')
  source.width = img.width; source.height = img.height
  const sourceContext = source.getContext('2d', { willReadFrequently: true })
  sourceContext.putImageData(img, 0, 0)
  const target = document.createElement('canvas')
  target.width = Math.max(1, Math.round(img.width * ratio)); target.height = Math.max(1, Math.round(img.height * ratio))
  const targetContext = target.getContext('2d', { willReadFrequently: true })
  targetContext.drawImage(source, 0, 0, target.width, target.height)
  return targetContext.getImageData(0, 0, target.width, target.height)
}
async function setBase(data, name, newPhoto) {
  face?.bitmap.close(); face = null
  base = data; result = data
  if (newPhoto) { original = data; fileName = name.replace(/\.[^.]+$/, ''); changed = false }
  resetSliders(); endCompare(); draw(data)
  canvas.hidden = false; $('empty').hidden = true
  $('photo-info').textContent = `${name} · ${data.width} × ${data.height}`
  status('照片已就绪。先调整强度，再应用效果；照片不会上传。')
}
async function loadFile(blob, name) {
  if (busy) return
  if (changed && !confirm('当前修改还未下载，仍要更换照片吗？')) return
  lock(true)
  try {
    if (blob.size > 40 * 1024 * 1024) throw new Error('图片超过 40 MB，请先压缩或换一张。')
    await setBase(await decode(blob), name, true)
  } catch(e) { status(e.message, true) }
  finally { lock(false); $('file').value = '' }
}
$('choose').onclick = $('empty-choose').onclick = () => $('file').click()
$('file').onchange = () => { if ($('file').files[0]) loadFile($('file').files[0], $('file').files[0].name) }
$('sample').onclick = async () => {
  try { const r = await fetch(`${import.meta.env.BASE_URL}sample.jpg`); if (!r.ok) throw Error(); await loadFile(await r.blob(), '人像示例.jpg') }
  catch { status('示例暂时无法加载，请选择本地照片。', true) }
}
$('stage').ondragover = (e) => { e.preventDefault() }
$('stage').ondrop = (e) => { e.preventDefault(); const file = e.dataTransfer.files[0]; if (file) loadFile(file, file.name) }
for (const id of controls) $(id).oninput = () => { $(`${id}-value`).value = $(id).value }
$('compare').onclick = () => {
  if (!result) return
  comparing = !comparing; draw(comparing ? original : result)
  $('compare').setAttribute('aria-pressed', String(comparing)); $('compare').textContent = comparing ? '返回效果' : '查看原图'
}
$('reset').onclick = () => { if (busy || !base) return; resetSliders(); result = base; endCompare(); status('已重置本轮人像效果，保留基础编辑。'); changed = true }
async function getEngine() {
  if (!engine) {
    const [lm, parsing, edit, types] = await Promise.all([
      import('./vendor/facestudio/engine/landmarks'), import('./vendor/facestudio/engine/parsing'),
      import('./vendor/facestudio/engine/edit'), import('./vendor/facestudio/engine/types')
    ])
    const progress = (name) => ({loading, frac}) => { if (loading && busy) status(`${name}${frac >= 0 ? ` ${Math.round(frac * 100)}%` : '…'}；首次加载稍慢，请稍候。`) }
    lm.onLandmarkerProgress(progress('加载人脸模型')); parsing.onParsingProgress(progress('加载人像分割模型'))
    engine = { ...lm, ...parsing, ...edit, ...types }
  }
  return engine
}
$('apply').onclick = async () => {
  if (!base || busy) return
  const smooth = Number($('smooth').value) / 100, slim = Number($('slim').value) / 100, blur = Number($('blur').value) / 100
  const teeth = Number($('teeth').value) / 100, smile = Number($('smile').value) / 100, eyes = Number($('eyes').value) / 100
  const nose = Number($('nose').value) / 100, brow = Number($('brow').value) / 100
  const active = smooth || slim || blur || teeth || smile || eyes || nose || brow
  if (!active) { result = base; endCompare(); status('效果强度为 0，已显示本轮原图。'); return }
  lock(true); endCompare(); status('准备人像引擎…')
  try {
    const E = await getEngine()
    if (!face) {
      const bitmap = await createImageBitmap(base)
      face = { id: crypto.randomUUID(), name: fileName, bitmap, width: base.width, height: base.height, landmarks: null }
    }
    if (!face.landmarks) { status('正在识别人脸…'); face.landmarks = await E.detectLandmarks(face.bitmap) }
    if (!face.landmarks) throw new Error('未检测到清晰人脸。请换一张正面人像；这张照片仍可使用基础编辑。')
    let parsing
    if (smooth || blur || teeth || brow) { status('正在识别皮肤和背景…'); parsing = await E.getParsing(face) }
    // Slim-only needs landmarks, not the segmentation model.
    result = await E.computeEdit(face, parsing, {
      ...E.DEFAULT_EDIT_SETTINGS, skinSmooth: smooth, faceSlim: slim,
      background: blur ? 'bokeh' : 'none', backgroundStrength: blur,
      teethWhiten: teeth, smile, eyeSize: eyes, noseSlim: nose, browDefine: brow
    }, undefined, () => status('正在应用人像效果…'))
    endCompare(); changed = true
    const parts = []
    if (smooth) parts.push(`磨皮 ${Math.round(smooth * 100)}`)
    if (slim) parts.push(`瘦脸 ${Math.round(slim * 100)}`)
    if (blur) parts.push(`虚化 ${Math.round(blur * 100)}`)
    if (teeth) parts.push(`美白 ${Math.round(teeth * 100)}`)
    if (smile) parts.push(`微笑 ${Math.round(smile * 100)}`)
    if (eyes) parts.push(`眼睛 ${Math.round(eyes * 100)}`)
    if (nose) parts.push(`鼻型 ${Math.round(nose * 100)}`)
    if (brow) parts.push(`眉形 ${Math.round(brow * 100)}`)
    status(`效果已更新 · ${parts.join(' / ')}。可查看原图或下载。`)
  } catch(e) { console.error('人像处理失败', e); status(e.message?.startsWith('未检测') ? e.message : '人像处理未完成。请检查网络后再次点「应用效果」；已选照片和基础编辑仍然保留。', true) }
  finally { lock(false) }
}
$('upscale').onclick = async () => {
  if (!result || busy) return
  lock(true); endCompare(); status('准备本地放大模型…')
  try {
    const { upscale } = await import('./vendor/facestudio/engine/upscale')
    const maxEdge = matchMedia('(max-width: 760px)').matches ? 448 : 512
    const input = resizeForUpscale(result, maxEdge)
    status(`放大输入 ${input.width} × ${input.height}；输出约 ${input.width * 4} × ${input.height * 4}。`)
    result = await upscale(input, 'general', (stage, frac) => {
      status(stage === 'download' ? `下载放大模型 ${Math.round(frac * 100)}%…` : `本地放大 ${Math.round(frac * 100)}%…`)
    })
    endCompare(); changed = true
    $('photo-info').textContent = `${fileName} · ${result.width} × ${result.height} · 本地 4x`
    status(`本地 4x 放大完成，输出 ${result.width} × ${result.height}。可查看原图或下载。`)
  } catch(e) {
    console.error('本地放大失败', e)
    status('本地放大未完成；当前画面仍保留，请稍后重试或换一张较小的照片。', true)
  } finally { lock(false) }
}
$('download').onclick = () => {
  if (busy || !result) return
  endCompare()
  canvas.toBlob((blob) => { if (!blob) { status('下载失败，请再试一次。', true); return }
    const url = URL.createObjectURL(blob), a = document.createElement('a')
    a.href = url; a.download = `${fileName}-修图.png`; a.click(); setTimeout(() => URL.revokeObjectURL(url), 60000)
    changed = false; status('图片已导出为 PNG。原文件不会被覆盖。')
  }, 'image/png')
}
function loadFilerobot() {
  if (!scriptPromise) scriptPromise = new Promise((resolve, reject) => {
    const s = document.createElement('script'); s.src = `${import.meta.env.BASE_URL}filerobot-4.9.0.min.js`
    s.onload = resolve; s.onerror = () => { s.remove(); scriptPromise = null; reject(Error('编辑器加载失败，请检查网络后重试。')) }; document.head.append(s)
  })
  return scriptPromise
}
function setBasicOpen(open) {
  dialog.hidden = !open; document.body.classList.toggle('basic-open', open)
  for (const node of document.querySelectorAll('main,header,footer')) node.inert = open
}
function closeBasic() { editor?.terminate(); editor = null; dirtyBasic = false; setBasicOpen(false); $('basic').focus() }
function requestClose() { if (!dirtyBasic || confirm('基础编辑尚未保存，确定放弃这次修改吗？')) closeBasic() }
$('close-basic').onclick = requestClose
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && !dialog.hidden && !document.querySelector('.SfxModal-Wrapper')) { e.preventDefault(); requestClose() }
})
$('basic').onclick = async () => {
  if (!result || busy) return
  endCompare(); dirtyBasic = false; setBasicOpen(true); $('close-basic').focus(); $('basic-status').textContent = '正在加载基础编辑器…'
  try {
    await loadFilerobot()
    if (dialog.hidden) return
    const F = window.FilerobotImageEditor
    editor = new F($('filerobot'), {
      source: canvas.toDataURL('image/png'), defaultSavedImageName: fileName,
      defaultSavedImageType: 'png', savingPixelRatio: 1, previewPixelRatio: 1,
      avoidChangesNotSavedAlertOnLeave: true, showBackButton: false, useBackendTranslations: false,
      language: 'zh', translations: {
        save: '保存并返回', saveAs: '保存图片', cancel: '取消', apply: '应用', reset: '重置',
        adjust: '裁剪旋转', finetune: '调色', filters: '滤镜', annotate: '标注', resize: '尺寸',
        crop: '裁剪', rotate: '旋转', flipX: '水平翻转', flipY: '垂直翻转',
        brightness: '亮度', contrast: '对比度', saturation: '饱和度', exposure: '曝光',
        text: '文字', draw: '画笔', rectangle: '矩形', ellipse: '椭圆', arrow: '箭头',
        width: '宽度', height: '高度', download: '下载', saveImage: '保存图片',
        adjustTab: '裁剪旋转', finetuneTab: '调色', filtersTab: '滤镜', annotateTabLabel: '标注', resizeTab: '尺寸',
        cropTool: '裁剪', rotateTool: '旋转', brightnessTool: '亮度', contrastTool: '对比度',
        textTool: '文字', penTool: '画笔', ellipseTool: '椭圆', rectangleTool: '矩形', arrowTool: '箭头',
        blurTool: '模糊', warmthTool: '色温', hsvTool: '色相饱和度', lineTool: '直线', polygonTool: '多边形',
        resetOperations: '重置全部编辑', undoTitle: '撤销', redoTitle: '重做', showImageTitle: '查看底图',
        zoomInTitle: '放大', zoomOutTitle: '缩小', toggleZoomMenuTitle: '缩放比例',
        saveAsModalTitle: '保存图片', imageName: '文件名', name: '名称', quality: '质量', format: '格式',
        extension: '扩展名', imageDimensionsHoverTitle: '图片尺寸（宽 × 高）', unFlipX: '取消水平翻转', unFlipY: '取消垂直翻转',
        original: '原始比例', custom: '自由裁剪', square: '正方形', landscape: '横向', portrait: '纵向',
        confirm: '确定', warning: '提示', discardChanges: '放弃修改', back: '返回', loading: '加载中…',
        fontFamily: '字体', size: '字号', opacity: '不透明度', stroke: '描边', position: '位置',
        changesLoseWarningHint: '重置会清除本次基础编辑，是否继续？',
        discardChangesWarningHint: '尚未保存本次修改，是否退出？', tabsMenu: '工具菜单'
      },
      tabsIds: [F.TABS.ADJUST, F.TABS.FINETUNE, F.TABS.FILTERS, F.TABS.ANNOTATE, F.TABS.RESIZE],
      defaultTabId: F.TABS.ADJUST,
      onModify: () => { dirtyBasic = true },
      onSave: async (image) => {
        try {
          $('basic-status').textContent = '正在保存…'
          const r = await fetch(image.imageBase64)
          await setBase(await decode(await r.blob()), fileName, false)
          changed = true; closeBasic(); status('基础编辑已保存，可以继续人像美化或下载。')
        } catch { $('basic-status').textContent = '保存失败，请重试。' }
      }
    })
    editor.render(); $('basic-status').textContent = ''
  } catch(e) { $('basic-status').textContent = e.message }
}
window.addEventListener('beforeunload', (e) => { if (changed || dirtyBasic) { e.preventDefault(); e.returnValue = '' } })
