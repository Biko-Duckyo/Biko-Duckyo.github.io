// Run after npm ci. Models are downloaded by curl/PowerShell as documented in README.
import { readFileSync, writeFileSync, mkdirSync, copyFileSync, readdirSync } from 'node:fs'
import { createHash } from 'node:crypto'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
const root = path.dirname(fileURLToPath(import.meta.url))
const models = path.join(root, 'public/models')
mkdirSync(models, {recursive:true})
const model = readFileSync(path.join(root, '../../.tmp/face_parsing.onnx'))
if (createHash('sha256').update(model).digest('hex') !== '0d9bd318e46987c3bdbfacae9e2c0f461cae1c6ac6ea6d43bbe541a91727e33f') throw Error('Invalid face parsing model')
// Cloudflare Pages limits each asset to 25 MiB; reassemble validated model in-browser.
const chunkSize = 20 * 1024 * 1024
const chunks = []
for (let i = 0; i * chunkSize < model.length; i++) {
  const chunk = model.subarray(i * chunkSize, (i + 1) * chunkSize)
  const name = `face-parsing-${i}.bin`; writeFileSync(path.join(models, name), chunk)
  chunks.push({ name, size: chunk.length })
}
writeFileSync(path.join(models, 'face-parsing.json'), JSON.stringify({ sha256:'0d9bd318e46987c3bdbfacae9e2c0f461cae1c6ac6ea6d43bbe541a91727e33f', chunks }))
for (const [from, to, filter] of [
  ['node_modules/@mediapipe/tasks-vision/wasm', 'wasm', () => true],
  ['node_modules/onnxruntime-web/dist', 'ort', name => /^ort-wasm-simd-threaded\.(wasm|mjs)$/.test(name)]
]) {
  mkdirSync(path.join(models, to), { recursive:true })
  for (const name of readdirSync(path.join(root, from)).filter(filter)) copyFileSync(path.join(root, from, name), path.join(models, to, name))
}
console.log('Validated and prepared same-origin photo models.')
